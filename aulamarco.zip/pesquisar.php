<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
</head>
<body>
    
<form action="pesquisar.php" method="post">
    Nome do cliente: <input type="text" name="nome" maxlength="40" placeholder="Digite o nome">
    <input type="submit" value="pesquisar" name="botao">
</form>

<?php
if(isset($_POST["botao"])){

    require("conecta.php");
    $nome=htmlentities($_POST["nome"]);

    $query = $mysqli->query("select * from clientes where nome like '%$nome%'");
    echo $mysqli->error;

    echo '
    <table border="1" width="600">
    <tr align="center">
        <td>ID</td>
        <td>CPF</td>
        <td>Nome do cliente</td>
    </tr>
    ';

    while ($tabela=$query->fetch_assoc()) {
        echo "
        <tr>
        <td align='center'>{$tabela['idcli']}</td>
        <td align='center'>{$tabela['cpf_cnpj']}</td>
        <td align='center'>{$tabela['nome']}</td>
        </tr>
        ";
    }
}  ?>
</body>
</html>
