<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Alterar Cliente</title>
</head>
<body>
    <h2>Alterar Cliente</h2>
    <a href="index.php">Voltar</a>
    <br><br>

<?php
require("conecta.php");

if (!isset($_GET['alterar'])) {
    echo "<p style='color:red;'>ID do cliente não informado.</p>";
    exit;
}

$idcli = $_GET['alterar'];

// Se o formulário foi enviado, atualiza os dados
if (isset($_POST['botao'])) {
    $nome = $_POST['nome'];
    $cpf_cnpj = $_POST['cpf_cnpj'];

    $sql = "UPDATE clientes SET nome='$nome', cpf_cnpj='$cpf_cnpj' WHERE idcli = $idcli";

    if ($mysqli->query($sql) === TRUE) {
        echo "<p style='color:green;'>Cliente atualizado com sucesso!</p>";
        echo '<a href="index.php">Voltar para lista</a>';
        exit;
    } else {
        echo "<p style='color:red;'>Erro ao atualizar cliente: " . $mysqli->error . "</p>";
    }
}

// Consulta os dados atuais para preencher o formulário
$sql = "SELECT nome, cpf_cnpj FROM clientes WHERE idcli = $idcli";
$result = $mysqli->query($sql);

if ($result->num_rows == 0) {
    echo "<p style='color:red;'>Cliente não encontrado.</p>";
    exit;
}

$cliente = $result->fetch_assoc();
?>

<form action="alterar.php?alterar=<?php echo $idcli; ?>" method="post">
    Nome: <input type="text" name="nome" maxlength="40" value="<?php echo htmlspecialchars($cliente['nome']); ?>" required /><br><br>
    CPF/CNPJ: <input type="text" name="cpf_cnpj" maxlength="20" value="<?php echo htmlspecialchars($cliente['cpf_cnpj']); ?>" required /><br><br>
    <input type="submit" value="Atualizar" name="botao" />
</form>

</body>
</html>
