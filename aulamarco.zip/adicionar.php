<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
</head>
<body>
<a href="index.php">Voltar</a>
    <br><br>
    <form action="adicionar.php" method="post">
        CPF: <input type="text" name="cpf_cnpj" maxlength="14" placeholder="Digite o CPF" required /><br><br>
        Nome do cliente: <input type="text" name="nome" maxlength="40" placeholder="Digite o nome" required /><br><br>
        <input type="submit" value="Adicionar" name="botao" />
    </form>
    
    <?php
    require("conecta.php");

    if (isset($_POST['botao'])) {
        $nome = $_POST['nome'];
        $cpf_cnpj = $_POST['cpf_cnpj'];

        $sql = "INSERT INTO clientes (nome, cpf_cnpj) VALUES ('$nome', '$cpf_cnpj')";

        if ($mysqli->query($sql) === TRUE) {
            echo "<p style='color:green;'>Cliente adicionado com sucesso!</p>";
        } else {
            echo "<p style='color:red;'>Erro ao adicionar cliente: " . $conexao->error . "</p>";
        }
    }
    ?>

</body>
</html>
    