<?php
$mysqli = new mysqli("localhost", "root", "", "agronegocio");

if ($mysqli->connect_error) {
    die("falha a conexão: " . $conexao->connect_error);
}
?>
