<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho</title>
</head>
<body>
    <h2>Cadastro de clientes</h2>
    <a href="adicionar.php">Adicionar</a>
    <a href="pesquisar.php">Pesquisar</a>
    <br>
    <table border="1" width="600">
        <tr align="center">
            <td>ID</td>
            <td>CPF</td>
            <td>Nome do cliente</td>
            <td>Ação</td>
        </tr>

    <?php

    require("conecta.php");

    $query = $mysqli->query("select * from clientes");
    echo $mysqli->error;

    while($tabela = $query->fetch_assoc()){
        echo "
        <tr><td align='center'>$tabela[idcli]</td>
        <td align='center'>$tabela[cpf_cnpj]</td>
        <td align='center'>$tabela[nome]</td>
        <td width='200'><a href='excluir.php?excluir=$tabela[idcli]'>[excluir]</a>
        <a href='alterar.php'?alterar=$tabela[idcli]'>[alterar]</a></td>
        </tr>
    ";}
    ?>
    </table>
</body>
</html>